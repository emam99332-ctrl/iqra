
import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';

import 'package:iqra/pages/azanPage.dart';
import 'package:iqra/pages/azkarPage.dart';
import 'package:iqra/pages/homePage.dart';
import 'package:iqra/pages/moshafPage.dart';
import 'package:iqra/pages/namesPage.dart';
import 'package:iqra/pages/radioPage.dart';
import 'package:iqra/pages/startupPage.dart';
import 'package:iqra/pages/surahPage.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.iqra.audio',
    androidNotificationChannelName: 'تلاوة القرآن الكريم',
    androidNotificationOngoing: true,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'اقرأ',
      initialRoute: '/startup',
      routes: {
        '/startup': (context) => Startuppage(),
        '/home': (context) => Homepage(),
        '/moshaf': (context) => Moshafpage(),
        '/surah': (context) => Surahpage(),
        '/azan': (context) => Azanpage(),
        '/radio': (context) => Radiopage(),
        '/names': (context) => Namespage(),
        '/azkar': (context) => Azkarpage(),
      },
    );
  }
}
