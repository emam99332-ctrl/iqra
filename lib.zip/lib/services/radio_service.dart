
import 'dart:async';
import 'dart:convert';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';

class RadioService extends ChangeNotifier {
  RadioService._() {
    _player.playerStateStream.listen((state) {
      _state = state;
      notifyListeners();
    });
  }

  static final RadioService instance = RadioService._();

  static const _uuid = '8e63e8b6-4e70-4bc0-9f5d-07e8477a4480';

  static const _fallbackUrl =
      'https://stream.radiojar.com/8s5u5tpdtwzuv';

  static const _hosts = [
    'de1.api.radio-browser.info',
    'de2.api.radio-browser.info',
    'all.api.radio-browser.info',
  ];

  final AudioPlayer _player = AudioPlayer();

  PlayerState? _state;
  List<String>? _urls;
  bool _starting = false;

  bool get isStarting => _starting;

  bool get isPlaying => _state?.playing ?? false;

  bool get isLoading {
    final s = _state;

    final buffering = s != null &&
        (s.processingState == ProcessingState.loading ||
            s.processingState == ProcessingState.buffering);

    return _starting || buffering;
  }

  Future<List<String>> _candidates() async {
    final urls = <String>[];

    for (final host in _hosts) {
      try {
        final res = await http
            .get(
          Uri.parse(
            'https://$host/json/stations/byuuid/$_uuid',
          ),
        )
            .timeout(const Duration(seconds: 8));

        if (res.statusCode != 200) continue;

        final list = jsonDecode(utf8.decode(res.bodyBytes)) as List;

        if (list.isEmpty) continue;

        for (final key in ['url_resolved', 'url']) {
          final u = list.first[key];

          if (u is String && u.isNotEmpty && !urls.contains(u)) {
            urls.add(u);
          }
        }

        break;
      } catch (e) {
        debugPrint('Radio host failed: $host ($e)');
      }
    }

    if (!urls.contains(_fallbackUrl)) {
      urls.add(_fallbackUrl);
    }

    return urls;
  }

  Future<String?> toggle() async {
    if (_player.playing) {
      await _player.stop();
      return null;
    }

    _starting = true;
    notifyListeners();

    try {
      final urls = _urls ??= await _candidates();

      for (final url in urls) {
        try {
          await _player.setAudioSource(
            AudioSource.uri(
              Uri.parse(url),
              tag: MediaItem(
                id: url,
                album: 'تطبيق اقرأ',
                title: 'إذاعة القرآن الكريم من القاهرة',
                artist: 'إذاعة القرآن الكريم',
              ),
            ),
          );

          unawaited(_player.play());

          return null;
        } on PlayerInterruptedException {
          return null;
        } on PlayerException catch (e) {
          debugPrint('Radio failed: $url (${e.message})');
        }
      }

      _urls = null;

      return 'تعذر تشغيل الإذاعة. الروابط التي تمت تجربتها:\n${urls.join('\n')}';
    } catch (e) {
      _urls = null;
      return 'تعذر تشغيل الإذاعة: $e';
    } finally {
      _starting = false;
      notifyListeners();
    }
  }

  Future<void> stop() => _player.stop();
}
