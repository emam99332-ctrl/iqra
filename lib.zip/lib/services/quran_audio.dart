import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:iqra/models/ayah.dart';
import 'package:iqra/services/apiService.dart';
import 'package:iqra/services/reciter_settings.dart';
import 'package:iqra/services/reciter_downloads.dart';
import 'package:iqra/services/radio_service.dart';

class QuranAudio extends ChangeNotifier {

  static const repeatCount = 1;

  final AudioPlayer _player = AudioPlayer();
  int _session = 0;

  bool isPlaying = false;
  bool isRepeating = false;
  int? playingSurah;
  int? playingAyahNumber;

  void _clear() {
    isPlaying = false;
    isRepeating = false;
    playingSurah = null;
    playingAyahNumber = null;
    notifyListeners();
  }

  Future<bool> _playOnce(Ayah ayah, int session) async {
    final reciter = ReciterSettings.instance.current;
    final local = await ReciterDownloads.instance
        .localPath(reciter.id, ayah.surahNumber, ayah.numberInSurah);
    final source =
        local ?? reciter.urlFor(ayah.surahNumber, ayah.numberInSurah);

    for (var attempt = 0; attempt < 3; attempt++) {
      if (session != _session) return false;
      try {
        if (local != null) {
          await _player.setFilePath(local);
        } else {
          await _player.setUrl(source);
        }
        if (session != _session) return false;

        unawaited(_player.play());
        await _player.processingStateStream.firstWhere(
              (s) => s == ProcessingState.completed || s == ProcessingState.idle,
        );
        if (session != _session) return false;

        final completed = _player.processingState == ProcessingState.completed;
        await _player.pause();
        if (completed) return true;
      } on PlayerInterruptedException {
        if (session != _session) return false;
      } on PlayerException catch (e) {
        debugPrint('ayah failed: $source (${e.message})');
      }
      await Future.delayed(const Duration(seconds: 1));
    }
    return true;
  }

  Future<void> playFromSurah(int startSurah) async {
    final session = ++_session;
    unawaited(RadioService.instance.stop());
    isPlaying = true;
    isRepeating = false;
    notifyListeners();
    try {
      for (var surah = startSurah; surah <= 114; surah++) {
        if (session != _session) return;
        final ayahs = await ApiService.getSurahAyahs(surah);
        if (session != _session) return;

        playingSurah = surah;
        notifyListeners();
        if (surah < 114) {
          ApiService.getSurahAyahs(surah + 1).then((_) {}, onError: (_) {});
        }

        for (final ayah in ayahs) {
          if (session != _session) return;
          playingAyahNumber = ayah.number;
          notifyListeners();
          if (!await _playOnce(ayah, session)) return;
        }
      }
    } finally {
      if (session == _session) _clear();
    }
  }

  Future<void> repeatAyah(Ayah ayah, {int times = repeatCount}) async {
    final session = ++_session;
    isPlaying = true;
    isRepeating = true;
    playingSurah = null;
    playingAyahNumber = ayah.number;
    notifyListeners();
    try {
      for (var i = 0; i < times; i++) {
        if (session != _session) return;
        if (!await _playOnce(ayah, session)) return;
      }
    } finally {
      if (session == _session) _clear();
    }
  }

  Future<void> stop() async {
    _session++;
    _clear();
    await _player.stop();
  }

  @override
  void dispose() {
    _session++;
    _player.dispose();
    super.dispose();
  }
}