import 'package:flutter/material.dart';
import 'package:iqra/pages/homePage.dart';
import 'package:iqra/services/apiService.dart';
import 'package:iqra/services/reciter_downloads.dart';
import 'package:iqra/styles/style.dart';

class Startuppage extends StatefulWidget {
  const Startuppage({super.key});

  @override
  State<Startuppage> createState() => _StartuppageState();
}

class _StartuppageState extends State<Startuppage> {
  String _status = 'جارٍ التحضير...';
  double? _progress;
  String? _error;
  bool _checking = true;

  @override
  void initState() {
    super.initState();
    ReciterDownloads.instance.init();
    _run();
    _checkDownloads();
  }

  Future<void> _checkDownloads() async {
    try {
      final quranDownloaded = await ApiService.isQuranDownloaded();
      final azkarDownloaded = await ApiService.isAzkarDownloaded();

      if (!mounted) return;

      if (quranDownloaded && azkarDownloaded) {
        _goHome();
      } else {
        _run();
      }
    } catch (e) {
      debugPrint('download check error: $e');

      if (!mounted) return;
      _run();
    }
  }

  Future<void> _run() async {
    if (!mounted) return;
    setState(() => _error = null);
    try {
      if (!await ApiService.isQuranDownloaded()) {
        if (!mounted) return;
        setState(() {
          _status = 'جارٍ تحميل المصحف...';
          _progress = null;
        });
        await ApiService.downloadQuran();
      }
      if (!await ApiService.isAzkarDownloaded()) {
        if (!mounted) return;
        setState(() {
          _status = 'جارٍ تحميل الأذكار...';
          _progress = 0;
        });
        await ApiService.downloadAzkar((done, total) {
          if (mounted) setState(() => _progress = done / total);
        });
      }
      _goHome();
    } catch (e) {
      debugPrint('startup error: $e');
      if (!mounted) return;
      setState(() => _error =
      'تعذر التحميل. تأكد من الاتصال بالإنترنت وحاول مرة أخرى.');
    }
  }

  void _goHome() {
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => Homepage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _checking
          ? const SizedBox.shrink()
          :Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'اِقـــرأ',
                    style: TextStyle(fontFamily: 'kufi', fontSize: 34),
                  ),
                  const SizedBox(height: 32),
                  if (_error == null) ...[
                    Text(_status, style: const TextStyle(fontSize: 18, fontFamily: 'ar', color: emerald)),
                    const SizedBox(height: 16),
                    LinearProgressIndicator(value: _progress, color: emerald,),
                    const SizedBox(height: 12),
                    const Text(
                      'يتم تجهيز البرنامج',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: gold, fontWeight: FontWeight.bold, fontFamily: 'ar'),
                    ),
                  ] else ...[
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: _run,
                      child: const Text('إعادة المحاولة'),
                    ),
                    TextButton(
                      onPressed: _goHome,
                      child: const Text('متابعة بدون تحميل'),
                    ),
                  ],
                ],
              ),
            ),
          ),
    );
  }
}